# APK com GitHub Actions

Este repositório compila um aplicativo Kivy em `.apk` automaticamente com GitHub Actions.

## Como usar

1. Crie um repositório no GitHub com esses arquivos.
2. Faça push na branch `main`.
3. Acesse a aba **Actions**, espere o workflow rodar.
4. Baixe o `.apk` no final do processo.

## Requisitos

- Conta GitHub
- Aplicativo Python com Kivy